"""Constants for neakasa_litterbox."""

from __future__ import annotations

from logging import Logger, getLogger

LOGGER: Logger = getLogger(__package__)

DOMAIN = "neakasa_litterbox"
MANUFACTURER = "Neakasa"
ATTRIBUTION = "Data provided by the Neakasa cloud"

DEFAULT_SCAN_INTERVAL_SECONDS = 600
MIN_SCAN_INTERVAL_SECONDS = 60

DEFAULT_STATISTICS_LOOKBACK_DAYS = 7
MIN_STATISTICS_LOOKBACK_DAYS = 1
MAX_STATISTICS_LOOKBACK_DAYS = 30

CONF_REGION = "region"
CONF_STATISTICS_LOOKBACK_DAYS = "statistics_lookback_days"

# Region codes are lowercase to satisfy HA's translation-key regex
# ([a-z0-9-_]+); the API client uppercases them when looking up the
# matching ``Region`` enum value in the SDK.
REGION_US = "us"
REGION_EU = "eu"
REGION_AP = "ap"
# Fork addition: the Chinese mainland cluster (region.neabot.com.cn).
REGION_CN = "cn"
REGIONS: tuple[str, ...] = (REGION_US, REGION_EU, REGION_AP, REGION_CN)
DEFAULT_REGION = REGION_US
